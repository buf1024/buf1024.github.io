---
title: 参考
date: 2016-03-29 14:47:02
---
### 参考资料

本页面为一些参考资料:  
- [camke参考](https://luoguochun.cn/ref/cmake.html)  
  [cmake](https://cmake.org) 为跨平台构建工具
