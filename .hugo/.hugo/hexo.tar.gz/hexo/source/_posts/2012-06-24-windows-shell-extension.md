layout:
  - post
title: 'Windows Shell Extension'
date: 2012-06-24 00:00:43
categories: windows  
tags: [win32] 
---

分享1，2年前自己还在搞WINDOWS开发时写的一个小工具（当时在公司无聊的时候写了很多小工具啊，只不过拿不出源代码，杯具），个人觉得挺实用的。当时这个东西叫做Filekeeper，目标就是监控程序对核心API的调用。后来搞得不伦不类。这个是从中提出的一部分源代码搞成一个实用的工具，改名为LGCUtil了，不过很多东西没改。  

运行结果如下：  
![WinShellExt](/img/winshext/win-shell-ext.jpg)  

目前只加两个命令，不过增加其它命令是非常容易的。连我这么多年不接触WINDOWS了，还是可以轻松加进去的。  
 源代码下载: [LGCUtil.Src](/raw/winshext/LGCUtil.Src.zip)  
 二进制文件下载：[LGCUtil.Bin](/raw/winshext/LGCUtil.Bin.zip)  
注意，下载二进制文件时，里面有两个批处理文件，修改里面的路径为你实际文件的路径。在WINDOWS 7/VISTA下面用管理员身份下载。  
因为失恋，又拿旧东西分享了一下。  

POST AT: https://luoguochun.cn/2012/06/24/windows-shell-extension/

