---
title: 'glfw -- 轻量级opengl窗口管理'
date: 2016-11-09 16:56:35
categories: opengl
tags: [opengl, glfw]
---

1. #include <GLFW/glfw3.h>

* 不要包含OpenGL头文件
* 不要包含windows.h 或其他平台相关的头文件
* 如果必须包括平台相关的头文件，在此头文件之前包含

在某些平台，OpenGL只提供旧版本的OpenGL头文件和连接库。使用其他Loader，无冲突替换平台的头文件，必须在glfw头文件之前替换。

#include <glad/glad.h>
#include  <GLFW/glfw3.h>

2. 使用glfw之前需要初始化，不再使用需要清理
if (!glfwInit()) {

}

glfwTerminate();

3. 事件是通过回调产生的，错误也是，错误回调函数在glfw初始化时调用
原型：void error_callback(int error, const char* description)
glfwSetErrorCallback(error_callback);

void button_callback(GLFWwindow*, int button, int action, int /*mods*/)
glfwSetMouseButtonCallback(window, button_callback);

void scroll_callback(GLFWwindow*, double /*xoffset*/, double yoffset)
glfwSetScrollCallback(window, scroll_callback);

void key_callback(GLFWwindow*, int key, int, int action, int mods)
glfwSetKeyCallback(window, key_allback);

void char_callback(GLFWwindow*, unsigned int c)
glfwSetCharCallback(window, char_callback);

不详细列举其他回调函数
4. 窗口或OpenGL上下信息由glfwCreateWindow创建，在创建之前，可以制定OpenGL的属性
glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
GLFWwindow* window = glfwCreateWindow(640, 480, "My Title", NULL, NULL);
if (!window)
{
    // Window or context creation failed
}
关闭窗口
glfwDestroyWindow(window);

5. 在使用OpenGL API之前，必须设置当前的OpenGL上下文信息
glfwMakeContextCurrent(window);

如果使用Loader使用现代OpenGL，还需要加载对于的API的地址，如glad

或者gl3w
    gl3wInit();
    
6. 每个窗口有一个标记标志是否关闭
while (!glfwWindowShouldClose(window))
{
    // Keep running
}

可以设置监听关闭事件
 glfwSetWindowCloseCallback
也可以设置关闭标志
 glfwSetWindowShouldClose
 
 7. 一旦设置了当前OpenGL上下文，就可以使用OpenGL API了
 
 8. GLFW维护一个定时器，从初始化到现在的秒数数
 double time = glfwGetTime();

 GLFW采用双缓冲，当整帧被渲染时，需要交换缓冲
 glfwSwapBuffers(window);
 
 交换间隔指示在交换缓冲之前有多少缓冲需要等待，通常设置为1
 glfwSwapInterval(1);
 
 9. 事件处理通常有两种方式，轮询和等待：
 glfwPollEvents();
glfwWaitEvents 


GLSL
OpenGL通过连接多个叫做着色器的小程序并佐以固定功能函数作为"胶水"来工作。

vertex shaders
tessellation control shaders
tessellation evaluation shaders
geometry shaders
fragment shaders
compute shaders
