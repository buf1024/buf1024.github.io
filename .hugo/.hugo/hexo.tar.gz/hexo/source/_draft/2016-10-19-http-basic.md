---
title: `http 概览` 
date: 2016-10-19 16:31:37
categories: http
tags: [http, https]
---

### http 概述
&emsp;&emsp;http协议是现代互联网通信最基本协议，协议的可靠性通过下层tcp保障，这里对http协议做最简单和粗略的小结。

&emsp;&emsp;在web服务器里面的所有的东西都称之为web资源，任意的web资源都有类型，称为媒体类型(MIME type)，如，`text/html text/plain image/jpeg`等，已定义的web类型有数百种。

&emsp;&emsp;任意的一个web资源都有一个URI(Uniform Resource Identifier)，URI包括两种，一种是与具体位置(服务器)相关的，URL(Uniform Resource Location)，另外一种是与位置无关的，URN(Uniform Resource Name)，URN目前存在理论中没有使用，所以URI和URL等同。URL的格式为：
        
        <scheme>://<usr>:<password>@<host>:<port>/<path>;<param>?<query>#<frag>
        
&emsp;&emsp;对于URL包括的特殊字符，需要进行转义。各种编程语言都有自己的`url_encode`和`url_decode`版本。

&emsp;&emsp;http支持5种方法：`GET PUT DELETE POST HEAD`，实际很少web服务全部实现，大部分web服务器只实现`GET POST HEAD`这三中方法。`GET`方法定义为从web服务器上获取资源，但实际上也可以实现为向web服务器上次资源；`POST`定义为向web服务器上传资源，实际上也可以实现为获取资源；用于何种用途完全取决于应用开发者。两者之间的一个重大区别是，`GET`，由于请求参数是放到URL中，所以实现上有长度限制，而`POST`并没有长度限制。

&emsp;&emsp;http定义了5种类型的状态码，分别为：

        100~199    提示信息返回码
        200~299    成功状态返回码
        300~399    重定向返回码
        400~499    客户端错误返回码
        500~599    服务端错误返回吗
        
&emsp;&emsp;我们常简单的返回码有：

        200        请求成功 
        301        临时不可用，应答的首部Location包含重定向的URL
        302        类似301，不同的是，客户端请求资源依然是
        304        表示http GET 资源没有被修改
        401        请求未授权
        403        请求被拒绝
        404        无法找到请求URL
        500        服务器内部错误
        503        服务临时不可用 

&emsp;&emsp;http报文格式：

        请求报文：
        <method> <url> <version><crlf>
        <headers><crlf>
        <crlf>
        <body>
        
        应答报文：
        <version> <status> <message><crlf>
        <headers><crlf>
        <crlf>
        <body>

### http 认证

### https
