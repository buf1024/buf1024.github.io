title: 实验室
date: 2015-06-12 07:17:24
---

### 实验室

本页面记录为了*好玩*而写一些东西:  
- [xinpinla-crawler](https://luoguochun.cn/xinpinla-crawler/)  
  从[新品啦](http://xinpinla.com)爬取数据，然后在以下页面（搜索网络待完善）搜索结果:  

  - [36氪--关注互联网创业官网](http://www.36kr.com)

 对于搜索不到的数据，则使用[新品啦](http://xinpinla.com)的简略数据。通过[hexo](http://hexo.io)生成[github pages](http://pages.github.com)，并部署在[github](https://github.com)上面。爬虫程序部署在[树莓派](http://www.raspberrypi.org)上面，通过自己写的[mysch](https://github.com/buf1024/mysch)调度监控。爬虫程序源码[xinpinla-crawler](https://github.com/buf1024/xinpinla-crawler)。  
        
 [树莓派](http://www.raspberrypi.org)因为一些特殊原因，早已经停止运行。2015-06-12。  

- [coffeescript-in-action](https://luoguochun.cn/coffeescript-in-action)  
  [coffeescript](http://coffeescript.org/)是[javascript](http://baike.baidu.com/link?url=CooG5RxYpjvxhZLmMq01_28O9J-ZF4XrJWKDJd_8-VZ1VoWZNo0umI0JjVMcDS-fnHIEibbgMWw4sRoyJgZcSq)的语法糖。[javascript](http://baike.baidu.com/link?url=CooG5RxYpjvxhZLmMq01_28O9J-ZF4XrJWKDJd_8-VZ1VoWZNo0umI0JjVMcDS-fnHIEibbgMWw4sRoyJgZcSq)是一般是用于web交互的一种脚本语言，由于google开源了一个非常优秀的javascript解析引擎v8，随后基于v8开发了运行于服务端的[nodejs](https://nodejs.org)。当[nodejs](https://nodejs.org)流行起来的时候，很多事情就可以用javascript做了。但是由于javascrip天生长的不好，过于灵活而导致很多歧义，于是就有了[coffeescript](http://coffeescript.org/)这种[javascript](http://baike.baidu.com/link?url=CooG5RxYpjvxhZLmMq01_28O9J-ZF4XrJWKDJd_8-VZ1VoWZNo0umI0JjVMcDS-fnHIEibbgMWw4sRoyJgZcSq)语法糖的出现，本质上就是javascript，只不过是用另外一种更优雅和容易理解并且不容易犯错的方式去使用javascript。    
  
  这是[《coffeescript in action》](http://www.manning.com/lee/)纯属翻译?或者笔记？我也不知道，反正是看了又忘记，忘记了又看，看了又忘记……如此循环，就想写写记录下来，或者这样不容易忘记，以后忘记了还可以回来参考下。
 
- [百度前端技术学院TASK](https://luoguochun.cn/ife2017)  
  小国勇老师开课，做TASK。

